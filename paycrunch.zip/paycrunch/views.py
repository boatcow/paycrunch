from django.shortcuts import render,redirect,get_object_or_404
from django.http import HttpResponse
from django.contrib.auth import authenticate, login
from django.http import Http404
from django.contrib.auth.decorators import login_required
from django.views.generic import ListView, DetailView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from db.models import *
from django_ajax.decorators import ajax
import datetime
# Create your views here.

@login_required(login_url = '/accounts/login/')
def index(request):
    user = request.user
    wallet = user.wallet
    if(wallet>=0):
        debit = 0
    else:
        debit= -wallet
        wallet = 0 
    bills = Bill.objects.filter().order_by('-date')[0:5]
    context = {
        'username' : user.username,
        'wallet':   wallet,
        'debit': debit,
        'bills': bills
    }
    return render(request,'db/index.html',context)

def test(request):
    return HttpResponse("Works")

def addToCart(request):
    return render(request, 'allahu.html',{})

@ajax
@login_required(login_url = '/accounts/login/')
def productsearch(request):
    if request.method == 'POST':
        barcode = request.POST.get("barcode")
        print(barcode)
        temp = request.user
        product= Products.objects.get(barcode = str(barcode))
        cart = Cart(uid = temp, pid = product, qty =1)
        cart.save()
        d = {
        'url':'/cart'
        }
        
        return d


@login_required(login_url = '/accounts/login/')
def billing(request):
    cartItems = Cart.objects.filter(uid = request.user)
    finalPrice =0 
    expiredItemNames= ""
    today  =datetime.date.today()
    for item in cartItems:
        finalPrice += item.pid.price * item.qty
        shopid = item.pid.shopid
        if(item.pid.expiry):
            if(today> item.pid.expiry):
                expiredItemNames += item.pid.Pname + " " 
    temp = request.user    
    wallet = temp.wallet
    if ( (wallet - finalPrice)>=-200 ):
        bill = Bill(userid = request.user, shopid = shopid, amount = finalPrice)
        bill.save()
        wallet = wallet - finalPrice
        temp.wallet = wallet
        temp.save()
        request.session['expired'] = expiredItemNames
        pk=Bill.objects.filter(userid = temp).values_list('id',flat=True).order_by('-date')[0]
        return redirect('/bill/'+str(pk), kwargs = expiredItemNames)
    else:
        return HttpResponse("Not enough cash")

class cartListView(ListView,LoginRequiredMixin):
    model = Cart
    def get_queryset(self):
        user = self.request.user
        return Cart.objects.filter(uid = user)

# class billDetailView(DetailView,LoginRequiredMixin,**kwargs):
#     model = Bill

@login_required(login_url = '/accounts/login/')
def billDetailView(request,pk,**kwargs):
    bill = get_object_or_404(Bill,pk=pk)
    temp = request.user
    print(**kwargs)
    cartItems = Cart.objects.filter(uid = temp)
    l =[]
    for i in range(len(cartItems)):
        l.append({'pname' : cartItems[i].pid.Pname, 
                'price' : cartItems[i].pid.price,
                'qty' : cartItems[i].qty
                })
    expiredItemNames = request.session['expired']
    print(expiredItemNames)
    length = len(l)
    context = { 
        'bill' : bill,
        'l': l,   
        'range': length ,
        'username' : temp.username,
        'expired': expiredItemNames
    }
    Cart.objects.filter(uid = temp).delete()
    return render(request,'db/bill_detail.html', context)

class billListView(ListView,LoginRequiredMixin):
    model = Bill
    def get_queryset(self):
        user = self.request.user
        return Bill.objects.filter(userid = user).order_by('-date')