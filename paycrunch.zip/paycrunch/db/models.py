from django.db import models
from django.contrib.auth.models import AbstractUser
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils import timezone

# Create your models here.
class user(AbstractUser):
    wallet = models.BigIntegerField(blank=True,null=True)
    debit = models.BigIntegerField(blank=True, null=True)

class Shops(models.Model):
    Sname = models.CharField(max_length=200)
    xcord = models.DecimalField(max_digits=10,decimal_places=3)
    ycord = models.DecimalField(max_digits=10,decimal_places=3)
    balance = models.DecimalField(max_digits=20,decimal_places=2)
    def __str__(self):
        return self.Sname

class Products(models.Model):
    shopid = models.ForeignKey(Shops, on_delete=models.CASCADE)
    barcode = models.CharField(max_length=30)
    price = models.DecimalField(max_digits=10,decimal_places=2)
    Pname = models.CharField(max_length=40)
    expiry = models.DateField(null=True,blank=True)
    def __str__(self):
        return self.Pname

class Bill(models.Model):
    shopid = models.ForeignKey(Shops, on_delete=models.CASCADE)
    userid = models.ForeignKey(user, on_delete=models.CASCADE)
    date = models.DateField(auto_now_add=True)
    amount = models.DecimalField(max_digits=10,decimal_places=2)
    def __str__(self):
        return self.id +" "+ self.userid +" "+ self.shopid

class userHistory(models.Model):
    userid = models.ForeignKey(user, on_delete=models.CASCADE)
    billid = models.ForeignKey(Bill, on_delete=models.CASCADE)
    def __str__(self):
        return self.id + " " +self.userid + " " +self.billid

class Cart(models.Model):
    pid = models.ForeignKey(Products,on_delete=models.CASCADE)
    uid = models.ForeignKey(user,on_delete=models.CASCADE)
    qty = models.IntegerField()