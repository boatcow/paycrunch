from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from django.contrib.auth import authenticate, login
from django.http import Http404
from django.contrib.auth.decorators import login_required
from django.views.generic import UpdateView, ListView, CreateView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from db.models import *
from django_ajax.decorators import ajax
import datetime as dt
import os
import datetime
from twilio.rest import Client
# Create your views here.


@login_required(login_url = '/accounts/login/')
def index(request):
    user = request.user
    wallet = user.wallet
    debit = user.debit
    bills = Bill.objects.filter().order_by('-date')[0:5]
    context = {
        'username' : user.username,
        'wallet':   wallet,
        'debit': debit,
        'bills': bills
    }
    return render(request,'db/index.html',context)

def test(request):
    return HttpResponse("Works")


def addToCart(request):
    return render(request, 'allahu.html', {})


@ajax
@login_required(login_url='/accounts/login/')
def productsearch(request):
    if request.method == 'POST':
        barcode = request.POST.get("barcode")
        print(barcode)
        temp = request.user
        product = Products.objects.get(barcode=str(barcode))
        cart = Cart(uid=temp, pid=product, qty=1)
        cart.save()
        d = {
            'url': '/cart'
        }

        return d


class bill_items():
    def __init__(self, name, price, quant, total):
        self.name = name
        self.price = price
        self.quant = quant
        self.total = total


@login_required(login_url='/accounts/login/')
def billing(request):
    cartItems = Cart.objects.filter(uid=request.user)
    l = []
    shopid = cartItems[0].pid.shopid
    finalprice = 0
    user = request.user
    wallet = user.wallet
    debit = user.debit
    post = request.POST
    today = datetime.date.today()
    expiredList = ""
    #print(post)
    for i in cartItems:
        n = i.pid.Pname
        expiry = i.pid.expiry
        if(expiry):
            if(today>expiry):
                expiredList += n
        p = float(i.pid.price)
        q = float(post[n])
        t = p*q
        finalprice += t
        b = bill_items(n, p, q, t)
        l.append(b)
    
    if(finalprice < wallet+debit):
        date = dt.date.today()
        d={
            'blist':l,
            'total':finalprice,
            'user' :request.user.username,
            'date' : date,
            'expired': expiredList,
        }
        account_sid = "AC0b500d773dae941d552ed27de46cf919"
        auth_token="bd5dbc5c61f7e88fa958ff663277da04"
        #auth_token=os.environ["TWILIO_AUTH_TOKEN"]
        if(finalprice>=1000):
            client= Client(account_sid,auth_token)
            call = client.calls.create(
                        to="+917639993250",
                        from_="+12075187477",
                        url="http://demo.twilio.com/docs/voice.xml"
                )
            cartItems.delete()
            return HttpResponse("<h1>Anomaly Detected</h1>")
        x = wallet - finalprice
        if(x <0):
            debit +=x
            x =0
        user.wallet = x
        user.debit  = debit
        user.save()
        bill = Bill(userid=request.user, shopid=shopid, amount=finalprice)
        bill.save()
        cartItems.delete()
        return render(request,'bill.html',d)
    else:
        return HttpResponse("<h1>You are out of cash<h1>")

class cart_items():
    def __init__(self, name, price):
        self.name = name
        self.price = price


@login_required(login_url='/accounts/login/')
def carts(request):
    c1 = Cart.objects.filter(uid=request.user)
    l = []
    for i in c1:
        obj = cart_items(i.pid.Pname, i.pid.price)
        l.append(obj)
    d = {
        'clist': l
    }
    return render(request, 'cart.html', d)
    

class billListView(ListView,LoginRequiredMixin):
    model = Bill
    def get_queryset(self):
        user = self.request.user
        return Bill.objects.filter(userid = user).order_by('-date')
