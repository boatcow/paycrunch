from django.contrib import admin
from django.urls import path,include
from . import views

app_name= 'db'

urlpatterns = [
    path('', views.index, name= "home"),
    path('productsearch', views.productsearch, name= "product search"),
    path('billing', views.billing, name= "billing"),
    path('add/', views.addToCart, name= "addcart"),
    #path('cart', views.cartListView.as_view(), name = 'cart'),
    path('cart',views.carts),
    path('billhistory', views.billListView.as_view(), name = 'billhistory'),
]
