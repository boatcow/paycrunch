from django.contrib import admin
from db.models import *
# Register your models here.
admin.site.register(Shops)
admin.site.register(user)
admin.site.register(Products)
admin.site.register(Bill)
admin.site.register(userHistory)
admin.site.register(Cart)


